<?php
session_start();
require 'connection.php';

if(isset($_GET['id'])) {
    $question_id = mysqli_real_escape_string($con, $_GET['id']);
    $query = "SELECT * FROM questionstore WHERE questID='$question_id'";
    $query_run = mysqli_query($con, $query);

    if(mysqli_num_rows($query_run) > 0) {
        $question = mysqli_fetch_assoc($query_run);
    } else {
        $_SESSION['message'] = "Question not found";
        header("Location: frontquestion.php");
        exit();
    }
} else {
    $_SESSION['message'] = "Invalid question ID";
    header("Location: frontquestion.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Edit Question</title>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <?php include_once'includes/sidebar.php';  ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php include_once'includes/header.php';  ?>
                <!-- End of Topbar -->

                <div class="container mt-5">

                    <?php include('message.php'); ?>

                    <div class="row">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-header">
                                    <h4>Edit Question
                                        <a href="frontquestion.php" class="btn btn-danger float-end">Cancel</a>
                                    </h4>
                                </div>
                                <div class="card-body">

                                    <form action="code.php" method="POST">

                                        <input type="hidden" name="questID" value="<?= $question['questID']; ?>">

                                        <div class="mb-3">
                                            <label for="questText" class="form-label">Question Text</label>
                                            <textarea class="form-control" id="questText" name="questText" rows="3" required><?= $question['questText']; ?></textarea>
                                        </div>
                                        <div class="mb-3">
                                            <label for="questType" class="form-label">Question Type</label>
                                            <select class="form-select" id="questType" name="questType" required>
                                                <option value="">Select Type</option>
                                                <option value="multiple_choice" <?= ($question['questType'] == 'multiple_choice') ? 'selected' : ''; ?>>Multiple Choice</option>
                                                <!-- Add other question types here -->
                                            </select>
                                        </div>
                                        <div class="mb-3">
                                            <label for="corrAnswer" class="form-label">Correct Answer</label>
                                            <input type="text" class="form-control" id="corrAnswer" name="corrAnswer" value="<?= $question['corrAnswer']; ?>" required>
                                        </div>
                                        <div class="mb-3">
                                            <label for="answOption" class="form-label">Answer Options</label>
                                            <textarea class="form-control" id="answOption" name="answOption" rows="3" required><?= $question['answOption']; ?></textarea>
                                            <div class="form-text">Enter answer options separated by commas.</div>
                                        </div>
                                        <button type="submit" name="update_question" class="btn btn-primary">Update Question</button>

                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

</div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <?php include_once ('includes/footer.php'); ?>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <?php include_once 'includes/logout.php' ?>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

</body>

</html>