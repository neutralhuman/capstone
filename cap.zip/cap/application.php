<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Application</title>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <link href="css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom styles for this page -->
    <style>
    .application-registration {
        max-width: 600px;
        margin: auto;
        padding: 40px;
        border-radius: 20px;
    }

        
    </style>
</head>

<body class="bg-gradient-form d-flex align-items-center">

    <div class="container">

        <div class="card o-hidden border-0 shadow-lg my-5 application-registration">
            <div class="card-body p-0">
                <!-- Nested Row within Card Body -->
                <div class="row">
                    <div class="col-lg-12">
                        <div class="p-5">
                            <div class="text-center">
                                <h1 class="h4 text-gray-900 mb-4">Register to Continue!</h1>
                            </div>
                            <form method="post" class="user">
                                
                                    <div class="form-group">
                                      
                                        <input type="text" name="fName" class="form-control form-control-user"
                                            placeholder="First Name">
                                    </div>
                                    <div class="form-group">
                                   
                                        <input type="text" name="lName" class="form-control form-control-user"
                                            placeholder="Last Name">
                                    </div>
                                    
                                
                                <div class= "form-group row">  
                                    <div class="col">
                                    
                                        <input type="text" name="mName" class="form-control form-control-user"
                                            placeholder="Middle Name">
                                    </div>
                                    <div class="col">
                                        <input type="text" name="suffix" class="form-control form-control-user"
                                            placeholder="Suffix">
                                    </div>
                                </div>
                            <div class= "form-group row">
                                <div class="col">
                                    <input type="text" name="lastSchool" class="form-control form-control-user"
                                        placeholder="Last School Attended">
                                </div>
                                <div class="col">
                                    <select name="prefCourse" class="form-control ">
                                        <option value="" disabled selected >Preferred Course</option>
                                        <option value="course1">Course 1</option>
                                        <option value="course2">Course 2</option>
                                        <option value="course3">Course 3</option>
                                    </select>
                                </div>
                            </div>
                            <div class= "form-group row">
                                <div class="col">
                                    <input type="date" name="dob" class="form-control form-control-user"
                                        placeholder="Date of Birth">
                                </div>
                                <div class="col">
                                    <input type="tel" name="num" class="form-control form-control-user"
                                        placeholder="Contact Number">
                                </div>
                            </div>
                                <div class="form-group">
                                    <label for="streetAdd">Address 1</label><br>
                                    <input type="text" name="address" class="form-control form-control-user"
                                        placeholder="House No. / Street / Subdivision">
                                </div>
                                <div class="form-group">
                                    <select name="region" class="form-control">
                                        <option value="" disabled selected>Select Region</option>
                                        <option value="region1">Region 1</option>
                                        <option value="region2">Region 2</option>
                                        <option value="region3">Region 3</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <select name="city" class="form-control ">
                                        <option disabled selected>Select City</option>
                                        <option value="city1">City 1</option>
                                        <option value="city2">City 2</option>
                                        <option value="city3">City 3</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <select name="brgy" class="form-control ">
                                        <option value="" disabled selected>Select Barangay</option>
                                        <option value="brgy1">Barangay 1</option>
                                        <option value="brgy2">Barangay 2</option>
                                        <option value="brgy3">Barangay 3</option>
                                    </select>
                                </div>
                                    
                                <a href="index.php" class="btn btn-primary btn-user btn-block" style="background-color: brown; color: white;">
                                    Continue
                                </a>
                                <hr>
                                <div class="text-center">
                                        <a class="small" href="register.php">Create an Account!</a>
                                </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

</body>

</html>
