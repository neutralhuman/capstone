<?php
session_start();
require 'connection.php';

// Add question
if(isset($_POST['save_question'])) {
    $questText = mysqli_real_escape_string($con, $_POST['questText']);
    $questType = mysqli_real_escape_string($con, $_POST['questType']);
    $corrAnswer = mysqli_real_escape_string($con, $_POST['corrAnswer']);
    $answOption = mysqli_real_escape_string($con, $_POST['answOption']);
    $creatTime = date('Y-m-d H:i:s');
    $modifiedTime = $creatTime;

    $query = "INSERT INTO questionstore (questText, questType, corrAnswer, answOption, creatTime, modifiedTime) VALUES ('$questText', '$questType', '$corrAnswer', '$answOption', '$creatTime', '$modifiedTime')";

    if(mysqli_query($con, $query)) {
        $_SESSION['message'] = "Question added successfully";
        header("Location: createquestion.php");
        exit();
    } else {
        $_SESSION['message'] = "Failed to add question: " . mysqli_error($con); // Provide error message
        header("Location: createquestion.php");
        exit();
    }
}

// Update question
if(isset($_POST['update_question'])) {
    $questID = mysqli_real_escape_string($con, $_POST['questID']);
    $questText = mysqli_real_escape_string($con, $_POST['questText']);
    $questType = mysqli_real_escape_string($con, $_POST['questType']);
    $corrAnswer = mysqli_real_escape_string($con, $_POST['corrAnswer']);
    $answOption = mysqli_real_escape_string($con, $_POST['answOption']);
    $modifiedTime = date('Y-m-d H:i:s');

    $query = "UPDATE questionstore SET questText='$questText', questType='$questType', corrAnswer='$corrAnswer', answOption='$answOption', modifiedTime='$modifiedTime' WHERE questID='$questID'";

    if(mysqli_query($con, $query)) {
        $_SESSION['message'] = "Question updated successfully";
        header("Location: frontquestion.php");
        exit();
    } else {
        $_SESSION['message'] = "Failed to update question: " . mysqli_error($con); // Provide error message
        header("Location: frontquestion.php");
        exit();
    }
}

// Soft delete question
if(isset($_POST['soft_delete_question'])) {
    $questID = mysqli_real_escape_string($con, $_POST['delete_question']);
    $query = "UPDATE questionstore SET isDeleted=1 WHERE questID='$questID'";

    if(mysqli_query($con, $query)) {
        $_SESSION['message'] = "Question soft deleted successfully";
        header("Location: frontquestion.php");
        exit();
    } else {
        $_SESSION['message'] = "Failed to soft delete question: " . mysqli_error($con); // Provide error message
        header("Location: frontquestion.php");
        exit();
    }
}
?>
