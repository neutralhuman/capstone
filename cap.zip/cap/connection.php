
<?php
// Define your database connection parameters
$dbhost = "localhost";
$dbuser = "root";
$dbpass = "paul123";
$dbname = "capstone";

// Create connection
$con = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);

// Check connection
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}



?>