<?php 
session_start();

include("connection.php");
include("functions.php");

// Initialize the error message variable
$error_message = "";

if($_SERVER['REQUEST_METHOD'] == "POST") {
    // Capture form data
    $fName = $_POST['fName'];
    $lName = $_POST['lName'];
    $mName = $_POST['mName'];
    $suffix = $_POST['suffix'];
    $username = $_POST['username'];
    $pwd = $_POST['pwd'];

    if(!empty($username) && !empty($pwd) && !is_numeric($username) && !empty($fName) && !empty($lName)) {
        // Save to database
        $user_id = random_num(20);
        $query = "insert into adminLogin (userid,fName,lName,mName,suffix,username,pwd) values ('$userid','$fName','$lName','$mName','$suffix','$username','$pwd')";

        mysqli_query($con, $query);

        header("Location: login.php");
        die;
    } else {
        $error_message = "Please enter some valid information!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Register</title>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <link href="css/sb-admin-2.css" rel="stylesheet">

</head>
<style>
    .card-registration {
            max-width: 600px;
            margin: auto;
            padding: 10px;
            border-radius: 40px;
        }
</style>
<body class="bg-gradient-form d-flex align-items-center">

    <div class="container">

        <div class="card o-hidden border-0 shadow-lg my-5 card-registration">
            <div class="card-body p-0">
                <!-- Nested Row within Card Body -->
                <div class="row justify-content-center"> <!-- Centering the content -->
                    <div class="col-lg-12">
                        <div class="p-5">
                            <div class="text-center">
                                <h1 class="h4 text-gray-900 mb-4">Create an Account!</h1>
                            </div>

                        <!-- Error message -->
                        <?php if(!empty($error_message)): ?>
                            <div class="alert alert-danger text-center" role="alert">
                                <?php echo $error_message; ?>
                            </div>
                            <?php endif; ?>

                            <form method="post" class="user">
                                <div class="form-group row">
                                    <div class="col-sm-6 mb-3 mb-sm-0">
                                        <input name="fName" type="text" class="form-control form-control-user" id="exampleFirstName"
                                            placeholder="First Name">
                                    </div>
                                    <div class="col-sm-6">
                                        <input name="lName" type="text" class="form-control form-control-user" id="exampleLastName"
                                            placeholder="Last Name">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-sm-6 mb-3 mb-sm-0">
                                        <input name="mName" type="text" class="form-control form-control-user" id="exampleFirstName"
                                            placeholder="Middle Name">
                                    </div>
                                    <div class="col-sm-6">
                                        <input name="suffix" type="text" class="form-control form-control-user" id="exampleLastName"
                                            placeholder="Name Extension">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <input name="username" type="email" class="form-control form-control-user" id="exampleInputEmail"
                                        placeholder="Email Address">
                                </div>
                                <div class="form-group">
                                        <input name="pwd" type="password" class="form-control form-control-user"
                                            id="exampleInputPassword" placeholder="Password">
                                </div>
                                
                                <button type="submit" class="btn btn-primary btn-user btn-block" style="background-color: brown; color: white;">
                                    Register Account
                                </button>
                            </form>
                            <hr>
                            <div class="text-center">
                                <a class="small" href="forgot-password.html">Forgot Password?</a>
                            </div>
                            <hr>
                            <div class="text-center">
                                <a class="small" href="login.php">Already have an account? Login!</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

</body>

</html>
