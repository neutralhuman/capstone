<?php
session_start();
require 'dbcon.php';

if(isset($_GET['id'])) {
    $question_id = mysqli_real_escape_string($con, $_GET['id']);
    $query = "SELECT * FROM questionstore WHERE questID='$question_id'";
    $query_run = mysqli_query($con, $query);

    if(mysqli_num_rows($query_run) > 0) {
        $question = mysqli_fetch_assoc($query_run);
    } else {
        $_SESSION['message'] = "Question not found";
        header("Location: index.php");
        exit();
    }
} else {
    $_SESSION['message'] = "Invalid question ID";
    header("Location: index.php");
    exit();
}
?>

<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <title>View Question</title>
</head>
<body>

<div class="container mt-5">

    <?php include('message.php'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4>Question Details
                        <a href="index.php" class="btn btn-danger float-end">Back</a>
                    </h4>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <label for="questText" class="form-label">Question Text</label>
                        <p class="form-control"><?= $question['questText']; ?></p>
                    </div>
                    <div class="mb-3">
                        <label for="questType" class="form-label">Question Type</label>
                        <p class="form-control"><?= $question['questType']; ?></p>
                    </div>
                    <div class="mb-3">
                        <label for="corrAnswer" class="form-label">Correct Answer</label>
                        <p class="form-control"><?= $question['corrAnswer']; ?></p>
                    </div>
                    <div class="mb-3">
                        <label for="answOption" class="form-label">Answer Options</label>
                        <p class="form-control"><?= $question['answOption']; ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
