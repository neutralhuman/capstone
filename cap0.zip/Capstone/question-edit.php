<?php
session_start();
require 'dbcon.php';

if(isset($_GET['id'])) {
    $question_id = mysqli_real_escape_string($con, $_GET['id']);
    $query = "SELECT * FROM questionstore WHERE questID='$question_id'";
    $query_run = mysqli_query($con, $query);

    if(mysqli_num_rows($query_run) > 0) {
        $question = mysqli_fetch_assoc($query_run);
    } else {
        $_SESSION['message'] = "Question not found";
        header("Location: index.php");
        exit();
    }
} else {
    $_SESSION['message'] = "Invalid question ID";
    header("Location: index.php");
    exit();
}
?>

<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <title>Edit Question</title>
</head>
<body>

<div class="container mt-5">

    <?php include('message.php'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4>Edit Question
                        <a href="index.php" class="btn btn-danger float-end">Cancel</a>
                    </h4>
                </div>
                <div class="card-body">

                    <form action="code.php" method="POST">

                        <input type="hidden" name="questID" value="<?= $question['questID']; ?>">

                        <div class="mb-3">
                            <label for="questText" class="form-label">Question Text</label>
                            <textarea class="form-control" id="questText" name="questText" rows="3" required><?= $question['questText']; ?></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="questType" class="form-label">Question Type</label>
                            <select class="form-select" id="questType" name="questType" required>
                                <option value="">Select Type</option>
                                <option value="multiple_choice" <?= ($question['questType'] == 'multiple_choice') ? 'selected' : ''; ?>>Multiple Choice</option>
                                <!-- Add other question types here -->
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="corrAnswer" class="form-label">Correct Answer</label>
                            <input type="text" class="form-control" id="corrAnswer" name="corrAnswer" value="<?= $question['corrAnswer']; ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="answOption" class="form-label">Answer Options</label>
                            <textarea class="form-control" id="answOption" name="answOption" rows="3" required><?= $question['answOption']; ?></textarea>
                            <div class="form-text">Enter answer options separated by commas.</div>
                        </div>
                        <button type="submit" name="update_question" class="btn btn-primary">Update Question</button>

                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
