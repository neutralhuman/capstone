<?php
session_start();
require 'dbcon.php';
?>

<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <title>Question Bank</title>
</head>
<body>

<div class="container mt-5">

    <?php include('message.php'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4>Question Bank
                        <a href="question-create.php" class="btn btn-primary float-end">Add Question</a>
                    </h4>
                </div>
                <div class="card-body">

                    <table class="table table-bordered">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th>Question Text</th>
                            <th>Question Type</th>
                            <th>Correct Answer</th>
                            <th>Actions</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php
                        $query = "SELECT * FROM questionstore WHERE isDeleted=1";
                        $query_run = mysqli_query($con, $query);

                        if (!$query_run) {
                            // Display error message if query fails
                            echo "<tr><td colspan='5'>Error: " . mysqli_error($con) . "</td></tr>";
                        } else {
                            if(mysqli_num_rows($query_run) > 0) {
                                $count = 0;
                                while($row = mysqli_fetch_assoc($query_run)) {
                                    $count++;
                                    ?>
                                    <tr>
                                        <td><?= $count; ?></td>
                                        <td><?= $row['questText']; ?></td>
                                        <td><?= $row['questType']; ?></td>
                                        <td><?= $row['corrAnswer']; ?></td>
                                        <td>
                                            <a href="question-view.php?id=<?= $row['questID']; ?>" class="btn btn-info btn-sm">View</a>
                                            <a href="question-edit.php?id=<?= $row['questID']; ?>" class="btn btn-success btn-sm">Edit</a>
                                            <form action="code.php" method="POST" class="d-inline">
                                                <input type="hidden" name="delete_question" value="<?= $row['questID']; ?>">
                                                <button type="submit" name="soft_delete_question" class="btn btn-danger btn-sm">Delete</button>
                                            </form>
                                        </td>
                                    </tr>
                                    <?php
                                }
                            } else {
                                // Display message if no questions found
                                echo "<tr><td colspan='5'>No questions found</td></tr>";
                            }
                        }
                        ?>
                        </tbody>
                    </table>

                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
