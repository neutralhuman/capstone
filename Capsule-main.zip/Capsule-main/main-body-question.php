<div id="layoutSidenav_content">
    <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">Question List</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active"><a href="index.php">Dashboard</a></li>
                            <li class="breadcrumb-item active">Subject Question</li>
                        </ol>
                        <div class="row">
                            
                        </div>
                        <!-- Table content -->
                        <div class="card mb-4">
                            <div class="card-header">
                                
                                
                                <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                                <a href="add_question.php" class="btn btn-primary" tabindex="-1" role="button" aria-disabled="true"> ADD QUESTION </a>
                            </div>
                            </div>
                            <div class="card-body">
                                <table id="datatablesSimple">
                                    <thead>
                                        <tr>
                                            <th>SUBJECT</th>
                                            <th>QUESTION NO.</th>
                                            <th>QUESTION</th>
                                            <th>CORRECT ANSWER</th>
                                            <th>ACTION</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>Science</td>
                                            <td>1</td>
                                            <td>What is the third planet in our solar system</td>
                                            <td>Earth</td>
                                            <td><div class="d-grid gap-2 d-md-flex justify-content-md-end">
                                <button class="btn btn-primary me-md-2" type="button">UPDATE</button>
                                <button class="btn btn-danger me-md-2" type="button">DELETE</button></td>
                                        </tr>
                                        <tr>
                                            <td>Science</td>
                                            <td>2</td>
                                            <td>What is the sign of Silver in table of contents</td>
                                            <td>I</td>
                                            <td><div class="d-grid gap-2 d-md-flex justify-content-md-end">
                                <button class="btn btn-primary me-md-2" type="button">UPDATE</button>
                                <button class="btn btn-danger me-md-2" type="button">DELETE</button></td>
                                        </tr>
                                        <tr>
                                            <td>Science</td>
                                            <td>3</td>
                                            <td>How many legs do centiped have</td>
                                            <td>100</td>
                                            <td><div class="d-grid gap-2 d-md-flex justify-content-md-end">
                                <button class="btn btn-primary me-md-2" type="button">UPDATE</button>
                                <button class="btn btn-danger me-md-2" type="button">DELETE</button></td>
                                        </tr>
                                        <tr>
                                            <td>Science</td>
                                            <td>4</td>
                                            <td>What is the sign of sulfur in table of contents</td>
                                            <td>Earth</td>
                                            <td><div class="d-grid gap-2 d-md-flex justify-content-md-end">
                                <button class="btn btn-primary me-md-2" type="button">UPDATE</button>
                                <button class="btn btn-danger me-md-2" type="button">DELETE</button></td>
                                        </tr>
                                        <tr>
                                            <td>Science</td>
                                            <td>5</td>
                                            <td>What is the hardest mineral in earth</td>
                                            <td>Diamond</td>
                                            <td><div class="d-grid gap-2 d-md-flex justify-content-md-end">
                                <button class="btn btn-primary me-md-2" type="button">UPDATE</button>
                                <button class="btn btn-danger me-md-2" type="button">DELETE</button></td>
                                        </tr>
                                        <tr>
                                            <td>Science</td>
                                            <td>6</td>
                                            <td>What color is a carrot</td>
                                            <td>carrot</td>
                                            <td><div class="d-grid gap-2 d-md-flex justify-content-md-end">
                                <button class="btn btn-primary me-md-2" type="button">UPDATE</button>
                                <button class="btn btn-danger me-md-2" type="button">DELETE</button></td>
                                        </tr>
                                        <tr>
                                            <td>English</td>
                                            <td>1</td>
                                            <td>Spell Red</td>
                                            <td>S.T.E.E.R</td>
                                            <td><div class="d-grid gap-2 d-md-flex justify-content-md-end">
                                <button class="btn btn-primary me-md-2" type="button">UPDATE</button>
                                <button class="btn btn-danger me-md-2" type="button">DELETE</button></td>
                                        </tr>
                                        <tr>
                                            <td>Science</td>
                                            <td>7</td>
                                            <td>if you jump in 3feet hole how deep is the hole</td>
                                            <td>25feet</td>
                                            <td><div class="d-grid gap-2 d-md-flex justify-content-md-end">
                                <button class="btn btn-primary me-md-2" type="button">UPDATE</button>
                                <button class="btn btn-danger me-md-2" type="button">DELETE</button></td>
                                        </tr>
                                    </tbody>
                                </table>

                            </div>
                        </div>
                    </div>
                <main>
                        