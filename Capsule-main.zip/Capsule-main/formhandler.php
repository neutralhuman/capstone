<?php 

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fname = $_POST["fname"];
    $lname = $_POST["lname"];
    $mi = $_POST["mi"];
    $suf = $_POST["suf"];
    $username = $_POST["username"];
    $pwd = $_POST["pwd"];
    $dob = $_POST["dob"]; 
    $age = $_POST["age"];
    $addr = $_POST["addr"];
    $num = $_POST["num"];
    $course = $_POST["course"];


    try {
        require_once "dbh.inc.php";

        $query = "INSERT INTO users (fname, lname, mi, suf, username, pwd, age, dob, addr, num, course ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);";

        $stmt = $pdo->prepare($query);

        $stmt->execute([$fname, $lname, $mi, $suf, $username, $pwd, $age, $dob, $addr, $num, $course]);

        $pdo = null;
        $stmt = null;

        header("Location: login.php");

        die();
    } catch (PDOException $e) {
        die("Query failed: " . $e->getMessage());
    }

} else {
    header("Location: registration.php");
    exit();
}


