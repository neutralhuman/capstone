<div id="layoutSidenav_content">
    <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">ADD SUBJECT</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
                            <li class="breadcrumb-item "><a href="subject.php">Subject</a></li>
                            <li class="breadcrumb-item active">ADD Subject</li>
                        </ol>
                        </ol>
                        <div class="row">
                            
                        </div>
                        <!-- Table content -->
        <Form action="registration.php" method="post">
                

            <div class="row">
                <div class="col-md-8 mb-6">

                  <div class="form-outline">
                    <input type="text" id="question" class="form-control form-control-lg" name = "question" placeholder="NEW SUBJECT" rows="3"/>
                    <label class="form-label" for="question">Add SUBJECT</label>
                  </div>

                </div>
            </div>


                <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                                <a href="question.php" class="btn btn-primary" tabindex="-1" role="button" aria-disabled="true"> Add  </a>
                                <a href="question.php" class="btn btn-danger" tabindex="-1" role="button" aria-disabled="true"> Cancel </a>
                            </div>

                            <div class="row">
                            </div>
            </form>
            

                    </div>
                <main>
                        