<title>Subject</title>
    <link rel="icon" type="image/x-icon" href="images/favicon.ico">
<?php include 'header.php'; ?>
<?php include 'menubar.php'; ?>
<?php include 'sidebar.php'; ?>
<?php include 'main-body-subject.php'; ?>
<?php include 'footer.php'; ?>

</body>
</html>