
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CSTA ENTRANCE EXAM</title>
    <link rel="icon" type="image/x-icon" href="images/favicon.ico">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style1.css">
</head>
<body>
    


  <div class="container">
        
        <div class="imgcontainer">
            <img src="images/logos.png" alt="avatar" class="img">
        </div>

            <h1><b> Colegio De Sta. Teresa De Avila </b></h1>
                    <h1> Entrance Examination </h1>

  
    <button id="show-register">Log in</button>
  </div> 
   


<div class="popup">
  <div class="close-btn">&times;</div>
    <div class="form padding:50;">
      <div class= "headers">
      <h2>Registration<h2>
      </div>
<form action="formhandler.php" method="POST">
<div class="row">
    <div class="form-group col-md-4">
      <label for="fname">Firs tName</label>
      <input type="text" class="form-control" id="firstname" name="fname"placeholder="FirstName" required>
    </div>
    <div class="form-group col-md-4">
      <label for="lname">Last Name</label>
      <input type="text" class="form-control" id="lastname" name="lname"placeholder="LastName" required>
    </div>
    <div class="form-group col-md-2">
      <label for="mi">Mi</label>
      <input type="text" class="form-control" id="middlename" name="mi"placeholder="Mi">
    </div>
    <div class="form-group col-md-2">
      <label for="sf">Suffix</label>
      <input type="text" class="form-control" id="sf" name="suf"placeholder="Sr/Jr">
    </div>
</div>
<div class="row">
    <div class="form-group col-md-6">
      <label for="user">Username</label>
      <input type="user" class="form-control" id="username" name="username"placeholder="Username" required>
    </div>
    <div class="form-group col-md-6">
      <label for="password">Password</label>
      <input type="password" class="form-control" id="password" name="pwd"placeholder="Password" required>
    </div>
</div>
<div class="row">
    <div class="form-group col-md-6">
      <label for="date">Date of Birth</label>
      <input type="date" class="form-control" id="date" name="dob"placeholder="" required>
    </div>
    <div class="form-group col-md-3">
      <label for="Age">Age</label>
      <input type="text" class="form-control" id="age" name="age"placeholder="Age">
    </div>
</div>
<div class="row">
  <div class="form-group col-md-12">
    <label for="address">Home Address</label>
    <input type="text" class="form-control" id="address" name="addr"placeholder="Home Address"required>
  </div>
</div>
<div class="row">
  <div class="form-group col-md-6">
      <label for="mobileno">Contact No.</label>
      <input type="text" class="form-control" id="mobileno" name="num"placeholder="Contact No."required>
    </div>
    <div class="form-group col-md-6">
      <label for="course">Preffered Course</label>
      <select id="course" name="course" class="form-control" required>
        <option selected value=1>BSIT</option>
        <option selected value=2>BSTM</option>
        <option selected value=3>BSHM</option>
        <option selected value=4>BEED</option>
      </select>
    </div>
</div>
<div class="form-element">
<button class="button" name="button" id="button">Register</button>
</div>
</form>


<script src="js/popup.js"></script>
</body>
</html>