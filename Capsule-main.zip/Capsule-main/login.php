<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Log-in / Sign-in</title>
    <link rel="icon" type="image/x-icon" href="images/favicon.ico">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/login.css">
</head>
<body>
    


<div class="header"> 
        <div class="imgcontainer">
            <img src="images/logos.png" alt="avatar" class="img">
        </div>
                    <h1> Entrance Examination </h1>

  
    

<div class="container">
  
        
            <h1><b>Log In<b></h1>
        
    <Form action="registration.php" method="post">

        <div class="form-group">
            <input type="text" class="form-control" name="user" id= "user" placeholder="Username:" require>
        </div>
        <div class="form-group">
            <input type="password" class="form-control" name="pw" id="pw" placeholder="Password:" require>
        </div>
    </form>

        <div class="submit">
            <button type="input" onclick="location.href='index.php'"> Log in </button>
        </div> 
</div>





</body>
</html>